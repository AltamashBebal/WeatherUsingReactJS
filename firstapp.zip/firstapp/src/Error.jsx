import React from 'react';

const Error=()=>{
  
        document.title="OOPS";

    return(
        <h1>OOOOPS  </h1>
    )
}

export default Error;