import React from 'react';

function Heading(props) {
    return <h1>
    </h1>
}
export default Heading;